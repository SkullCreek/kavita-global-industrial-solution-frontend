"use client";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";

// Import Swiper styles
import "swiper/css/pagination";
import "swiper/css";

import Image from "next/image";

const HeroCarousal = () => {
  return (
    <Swiper
      spaceBetween={30}
      centeredSlides={true}
      autoplay={{
        delay: 2500,
        disableOnInteraction: false,
      }}
      pagination={{
        clickable: true,
      }}
      modules={[Autoplay, Pagination]}
      className="hero-carousel"
    >
      <SwiperSlide>
        <div className="flex items-center pt-6 sm:pt-0 flex-col-reverse sm:flex-row">
          <div className="max-w-[394px] py-10 sm:py-15 lg:py-24.5 pl-4 sm:pl-7.5 lg:pl-12.5">
            <div className="flex items-center gap-4 mb-7.5 sm:mb-10">
              <span className="block font-semibold text-heading-3 sm:text-heading-1 text-blue">
                100%
              </span>
              <span className="block text-dark text-sm sm:text-custom-1 sm:leading-[24px]">
                Genuine
                <br />
                Parts
              </span>
            </div>

            <h1 className="font-semibold text-dark text-xl sm:text-3xl mb-3">
              <a href="/shop-without-sidebar">
                Industrial Trading & Engineering Services
              </a>
            </h1>

            <p>
              Machinery, sealing, fluid handling, and electrical power systems
              — your one-stop supplier for industrial components.
            </p>

            <a
              href="/shop-without-sidebar"
              className="inline-flex font-medium text-white text-custom-sm rounded-md bg-dark py-3 px-9 ease-out duration-200 hover:bg-blue mt-10"
            >
              Browse Catalogue
            </a>
          </div>

          <div>
            <Image
              src="/images/catalogue/corrugated-cardboard-production-line-1-1.jpeg"
              alt="industrial machinery and spares"
              width={351}
              height={351}
              className="object-contain"
            />
          </div>
        </div>
      </SwiperSlide>
      <SwiperSlide>
        {" "}
        <div className="flex items-center pt-6 sm:pt-0 flex-col-reverse sm:flex-row">
          <div className="max-w-[394px] py-10 sm:py-15 lg:py-26 pl-4 sm:pl-7.5 lg:pl-12.5">
            <div className="flex items-center gap-4 mb-7.5 sm:mb-10">
              <span className="block font-semibold text-heading-3 sm:text-heading-1 text-blue">
                24/7
              </span>
              <span className="block text-dark text-sm sm:text-custom-1 sm:leading-[24px]">
                Support
                <br />
                Team
              </span>
            </div>

            <h1 className="font-semibold text-dark text-xl sm:text-3xl mb-3">
              <a href="/contact">Trading &amp; Services You Can Rely On</a>
            </h1>

            <p>
              Get quick assistance and genuine spare parts for your industrial plants
              — just a WhatsApp message away.
            </p>

            <a
              href="/contact"
              className="inline-flex font-medium text-white text-custom-sm rounded-md bg-dark py-3 px-9 ease-out duration-200 hover:bg-blue mt-10"
            >
              Enquire Now
            </a>
          </div>

          <div>
            <Image
              src="/images/catalogue/automatic-high-speed-printing-slotting-d-15-1.jpeg"
              alt="industrial equipment trading and services"
              width={351}
              height={351}
              className="object-contain"
            />
          </div>
        </div>
      </SwiperSlide>
    </Swiper>
  );
};

export default HeroCarousal;
