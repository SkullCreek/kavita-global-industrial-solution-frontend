import React from "react";
import Image from "next/image";
import { whatsappLink, PHONE_TEL, PHONE_DISPLAY } from "@/constants/contact";

const Newsletter = () => {
  return (
    <section className="overflow-hidden">
      <div className="max-w-[1170px] mx-auto px-4 sm:px-8 xl:px-0">
        <div className="relative z-1 overflow-hidden rounded-xl">
          {/* <!-- bg shapes --> */}
          <Image
            src="/images/shapes/newsletter-bg.jpg"
            alt="background illustration"
            className="absolute -z-1 w-full h-full left-0 top-0 rounded-xl"
            width={1170}
            height={200}
          />
          <div className="absolute -z-1 max-w-[523px] max-h-[243px] w-full h-full right-0 top-0 bg-gradient-1"></div>

          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8 px-4 sm:px-7.5 xl:pl-12.5 xl:pr-14 py-11">
            <div className="max-w-[491px] w-full">
              <h2 className="max-w-[399px] text-white font-bold text-lg sm:text-xl xl:text-heading-4 mb-3">
                Can&apos;t Find the Part You Need?
              </h2>
              <p className="text-white">
                Tell us the machine model and part name — we&apos;ll help you
                source it. No online payment needed, just reach out directly.
              </p>
            </div>

            <div className="max-w-[477px] w-full">
              <div className="flex flex-col sm:flex-row gap-4">
                <a
                  href={whatsappLink(
                    "Hi, I'm looking for a spare part for my Flexo printing machine that I couldn't find listed. Can you help?"
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex justify-center py-3 px-7 text-white bg-blue font-medium rounded-md ease-out duration-200 hover:bg-blue-dark"
                >
                  Enquire on WhatsApp
                </a>
                <a
                  href={`tel:${PHONE_TEL}`}
                  className="inline-flex justify-center py-3 px-7 text-dark bg-white font-medium rounded-md ease-out duration-200 hover:bg-gray-1"
                >
                  Call {PHONE_DISPLAY}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;
